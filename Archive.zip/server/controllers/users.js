var mongoose = require('mongoose')
var User = mongoose.model('User')
var Product1 = mongoose.model('Product1')



console.log("I am at the users Controller-Backend")

function UsersController() {

    this.addUser = function(req, res) {
        User.findOne({ name: req.body.name, id: req.body._id }, function(err, user) {
            if (err) {
                res.json(err)
            } else {
                if (user == null) {
                    var newUser = User({ name: req.body.name })
                    newUser.save(function(newerr) {
                        if (newerr) {
                            res.json(newerr)
                        } else {
                            res.json(newUser)
                        }
                    })
                } else { res.json(user) }
            }


        })
    }


    this.getUser = function(req, res) {
        User.find({}).populate('_user').exec(function(err, users) {
            if (err) {
                res.json(err)
            } else {
                res.json(users)
            }
        })
    }

    this.product1_bid = function(req,res) {
    Product1.findOne({ username:req.body.username,bid: req.body.bid, id: req.body._id}, function(err, product1) {
        if (err) {
            res.json(err)
        } else {
            if (product1 == null) {
                var newProduct1_bid= Product1({username:req.body.username, bid: req.body.bid, id: req.body._id})
                newProduct1_bid.save(function(newerr) {
                    if (newerr) {
                        res.json(newerr)
                    } else {
                        res.json(newProduct1_bid)
                    }
                })
            } else { res.json(product1) }
            }
        })
    }




    this.get_product1= function(req, res) {
        Product1.find({}).populate('_product1').exec(function(err, products) {
            if (err) {
                res.json(err)
            } else {
                res.json(products)
            }
        })
    }

}

   
module.exports = new UsersController();