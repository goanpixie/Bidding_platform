console.log('routes')
var users = require('../controllers/users.js');
module.exports = function(app){

	app.post('/add_user', users.addUser)
	app.get('/get_user', users.getUser)
	app.post('/product1_bid',users.product1_bid)
	app.get('/get_product1',users.get_product1)
	


}
