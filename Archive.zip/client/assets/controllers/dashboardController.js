app.controller('dashboardController', ['$scope', '$location', 'userFactory', '$cookies',function($scope, $location, userFactory, $cookies) {

    $scope.errors = false;
    $scope.messages = [];
    $scope.newUser;
    $scope.product1_bids = [];
    $scope.product1 = {};


    
    if($cookies.getObject('newUser')){
		$scope.newUser = $cookies.getObject('newUser')
	}
	else{
		$location.url('/home')
	}


    $scope.getUser = function() {
        userFactory.getUser(function(data) {
            $scope.users = data
        })
    };
    $scope.getUser();


	$scope.logout = function(){
		$cookies.remove('newUser')
		$location.url('/home')

	}

	$scope.product1_bid = function() {
		$scope.product1.username = $scope.newUser.name;
        userFactory.product1_bid($scope.product1, function(data) {
            $scope.messages = []
            if (data.errors) {
                $scope.errors = true;
                for (err in data.errors) {
                    console.log(data.errors[err].message)
                    $scope.messages.push(data.errors[err].message)
                }
            }
        
        })

            $scope.getproduct1_bid();
    }


    $scope.getproduct1_bid = function() {
        userFactory.getproduct1_bid(function(data) {
            $scope.product1_bids = data
        })
    };
    $scope.getproduct1_bid();

}])